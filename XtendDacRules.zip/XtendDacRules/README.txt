Installation instructions:
Copy XtendDacRules.dll to the DAC extensions folder of your Visual Studio installation.
For Visual Studio 2013 this is:
C:\Program Files (x86)\Microsoft Visual Studio 12.0\Common7\IDE\Extensions\Microsoft\SQLDB\DAC\120\Extensions

Only start Visual Studio after you have copied the dll into the folder.
